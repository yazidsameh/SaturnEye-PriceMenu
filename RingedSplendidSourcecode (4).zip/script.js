<div>
  <h1 class="slogen">Your Vision, Our Design</h1>
</div>
<ul>
  <li>
    <span class="fas fa-home" id="headIcon"></span>
    <a href="#main"> Home </a>
  </li>
  <li>
    <span class="fa-regular fa-image" id="headIcon"></span>
    <a href="#services"> Services </a>
  </li>
  <li>
    <span class="fas fa-question-circle" id="headIcon"></span>
    <a href="#"> Help </a>
  </li>
  <li>
    <span class="fa-solid fa-phone" id="headIcon"></span>
    <a href="#"> Contact </a>
  </li>
</ul>